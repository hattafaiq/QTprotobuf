#include <QCoreApplication>
#include "coba_lagi.h"
int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    coba_lagi bisyuk;
    return a.exec();
}
