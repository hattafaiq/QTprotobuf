#include <QCoreApplication>
#include "bisa.h"
int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    bisa yuk;
   // yuk.mulai();
    return a.exec();
}
