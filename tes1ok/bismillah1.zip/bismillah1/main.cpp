#include <QCoreApplication>
#include "coba_dulu.h"

//using tutorial::Person;

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    coba_dulu c;
    return a.exec();
    //tutorial::Person();
}
