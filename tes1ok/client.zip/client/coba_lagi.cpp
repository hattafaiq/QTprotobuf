#include "coba_lagi.h"
#include <QtNetwork>
#include <google/protobuf/message.h>
#include <iostream>
#include "road.pb.h"

coba_lagi::coba_lagi(QObject *parent) : QObject(parent)
{
    Test();
}

coba_lagi::~coba_lagi()
{

}

void coba_lagi::Test()
{
    socket = new QTcpSocket(this);
    connect(socket, SIGNAL(connected()), this, SLOT(connected()));
    connect(socket, SIGNAL(disconnected()), this, SLOT(disconnected()));
    connect(socket, SIGNAL(readyRead()), this, SLOT(readyRead()));
    connect(socket, SIGNAL(bytesWritten(qint64)), this, SLOT(bytesWritten(qint64)));

    qDebug() << "Connecting,..";

    socket->connectToHost("127.0.0.1", 2312);

    if(!socket->waitForDisconnected(1000))
    {
        qDebug() << "Error: " << socket->errorString();
    }

}

void coba_lagi::connected()
{

    socket->write("HEAD / HTTP/1.0\r\n\r\n\r\n\r\n");
}

void coba_lagi::disconnected()
{
    qDebug() << "Disconnected!";
}

void coba_lagi::bytesWritten(qint64 bytes)
{
    qDebug() << "We wrote: " << bytes;
}

void coba_lagi::readyRead()
{
    qDebug() << "Reading...";
    qDebug() << socket->readAll();
}


