#include "coba_lagi.h"
#include <QtNetwork>
#include <google/protobuf/message.h>
#include <iostream>
#include "road.pb.h"

coba_lagi::coba_lagi(QObject *parent) : QObject(parent)
{
    Test();
}

coba_lagi::~coba_lagi()
{

}

void coba_lagi::Test()
{
    socket = new QTcpSocket(this);
    socket->connectToHost("127.0.0.1", 2312);
    connect(socket, SIGNAL(connected()), this, SLOT(connected()));
    connect(socket, SIGNAL(disconnected()), this, SLOT(disconnected()));
}

void coba_lagi::connected()
{
    qDebug() << "Connected";
    tutorial::Person message;
   // message.set_id(1);
    message.set_name("Hallo, broo!");
    const int size = message.ByteSizeLong();
    std::unique_ptr<char[]> buffer(new char[size]);
    message.SerializeToArray(buffer.get(), size);
    QByteArray data;
    message.SerializeToArray(data.data(), data.size());
    socket->write(buffer.get(), size);
    connect(socket, SIGNAL(readyRead()), this, SLOT(readyRead()));
}

void coba_lagi::disconnected()
{
    qDebug() << "Disconnected!";
}

void coba_lagi::readyRead()
{
    QTcpSocket *socken = qobject_cast<QTcpSocket *>(sender());
    if (!socket) {
      return;
    }
    tutorial::Person message;
    char recvBuffer[1024];
    socken->read(recvBuffer, sizeof(recvBuffer));
    message.ParseFromArray(recvBuffer, socket->bytesAvailable());
    QString str;
    str.sprintf("%s",recvBuffer);
    qDebug() << "1Received: " << str;
    qDebug() << "2Received: " << recvBuffer;
}


