#include "bisa.h"

bisa::bisa(QObject *parent) : QObject(parent)
{
    server = new QTcpServer(this);
    if (!server->listen(QHostAddress::Any, 2312)) {
      qDebug() << "Failed to start server:" << server->errorString();
      return;
    }
    connect(server, SIGNAL(newConnection()), this, SLOT(newConnection()));

    qDebug() << "Server listening on" << server->serverAddress().toString() << ":" << server->serverPort();
}

bisa::~bisa()
{

}

void bisa::mulai()
{

}

void bisa::socketReadyRead()
{
    QTcpSocket *socket = qobject_cast<QTcpSocket *>(sender());
    if (!socket) {
      return;
    }
    tutorial::Person message;
    char recvBuffer[1024];
    socket->read(recvBuffer, sizeof(recvBuffer));
    message.ParseFromArray(recvBuffer, socket->bytesAvailable());
    QString str;
    str.sprintf("%s",recvBuffer);
    qDebug() << "1Received: " << str;
    qDebug() << "2Received: " << recvBuffer;
}

void bisa::socketDisconnected()
{
    QTcpSocket *socket = qobject_cast<QTcpSocket *>(sender());
    if (!socket) {
      return;
    }
    sockets.removeOne(socket);
    socket->deleteLater();
    qDebug() << "Client disconnected";
}

void bisa::newConnection()
{

    tutorial::Person message;
    message.set_name("Hello, world!");
    const int size = message.ByteSizeLong();
    std::unique_ptr<char[]> buffer(new char[size]);
    message.SerializeToArray(buffer.get(), size);
    QByteArray data;
    message.SerializeToArray(data.data(), data.size());

//    // Send the serialized data over the network using Qt
    QTcpSocket *socket = server->nextPendingConnection();
//    //socket->write("hey client");
    socket->write(buffer.get(), size);
    connect(socket, &QTcpSocket::readyRead, this, &bisa::socketReadyRead);
    connect(socket, &QTcpSocket::disconnected, this, &bisa::socketDisconnected);
}


